//***myprofile_rt.js is the main router for the user's profile backend, its html rendering,
//*** and its necessary access/refresh tokens (if any).

const express = require("express");
const router = express.Router();
const mysql = require("mysql2/promise");
const cookieParser = require("cookie-parser");
const jwt = require("jsonwebtoken");
const { redirect } = require("statuses");

// Parse cookies in the request headers
router.use(cookieParser());

require("dotenv").config();

//** Database
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
});

//router for profile page
// Add this route to fetch user profile
router.route("/").get(async (req, res) => {
  const accessToken = req.cookies.accessToken;

  // Verify access token
  jwt.verify(
    accessToken,
    process.env.ACCESS_TOKEN_SECRET,
    async (err, user) => {
      if (err) {
        return res.status(403).json({
          message: "Invalid access token! Cannot fetch profile!",
        });
      }

      // Fetch the user's email from the database
      try {
        const [rows] = await pool.query(
          "SELECT email, is_admin FROM users WHERE email = ?",
          [user.email]
        ); // Fetch both email and is_admin

        if (rows.length > 0) {
          const userEmail = rows[0].email; // Get the email from the database
          const isAdmin = rows[0].is_admin; // Get the is_admin status from the database
          res.render("myprofile", {
            title: "User Profile",
            siteName: "Worst Buy",
            email: userEmail, // Pass the email to the EJS template
            isAdmin: isAdmin, // Pass the is_admin status to the EJS template
          });
        } else {
          return res.status(404).json({ message: "User not found" });
        }
      } catch (error) {
        return res.status(500).json({ message: "Database query error" });
      }
    }
  );
});

router.route("/send_admin_code").post(async (req, res) => {
  const accessToken = req.cookies.accessToken;

  if (!accessToken) return res.status(403).json({ message: "Unauthorized" });

  // Decode the access token to get the user's email
  const user = jwt.verify(
    accessToken,
    process.env.ACCESS_TOKEN_SECRET,
    async (err, user) => {
      if (err)
        return res
          .status(403)
          .json({ message: "Invalid access token. Cannot send admin code!" });
      try {
        // Fetch the user by email
        const [rows] = await pool.query("SELECT * FROM users WHERE email = ?", [
          user.email,
        ]);

        if (rows.length > 0) {
          const userId = rows[0].id;

          // Generate a random admin code (you can implement your own logic for this)
          const adminCode = Math.random().toString(36).substring(2, 8);

          // Store the admin code in the `admin_code` column for the user
          await pool.query("UPDATE users SET admin_code = ? WHERE id = ?", [
            adminCode,
            userId,
          ]);

          // Send the admin code to the user's email (implement your email sending logic)
          // For demonstration, we'll just log the email sending action
          console.log(`Admin code ${adminCode} sent to ${user.email}`);

          return res.status(200).json({ message: "Admin code request sent!" });
        } else {
          return res.status(404).json({ message: "User not found." });
        }
      } catch (error) {
        console.error("Error sending:", error);
        return res.status(500).json({ message: "Server error." });
      }
    }
  );
});

router.route("/verify_admin_code").post(async (req, res) => {
  const { adminCode } = req.body;
  const accessToken = req.cookies.accessToken;

  if (!accessToken) return res.status(403).json({ message: "Unauthorized" });

  // Decode the access token to get the user's email
  jwt.verify(
    accessToken,
    process.env.ACCESS_TOKEN_SECRET,
    async (err, user) => {
      if (err)
        return res
          .status(403)
          .json({ message: "Invalid access token. Cannot verify admin code!" });

      try {
        // Fetch the user by email and admin_code in a single query
        const [rows] = await pool.query(
          "SELECT * FROM users WHERE email = ? AND admin_code = ?",
          [user.email, adminCode]
        );

        if (rows.length === 0) {
          return res
            .status(400)
            .json({ message: "Invalid admin code or user not found." });
        }

        const userId = rows[0].id;
        const isAdmin = rows[0].is_admin;

        if (isAdmin) {
          return res.status(400).json({ message: "You are already an admin." });
        }

        // Update is_admin to true
        await pool.query("UPDATE users SET is_admin = ? WHERE id = ?", [
          true,
          userId,
        ]);
        return res.status(200).json({ message: "You are now an admin!" });
      } catch (error) {
        console.error("Error verifying admin code:", error);
        return res.status(500).json({ message: "Server error." });
      }
    }
  );
});

// Route to log out and clear cookies
router.route("/logout").post((req, res) => {
  try {
    // Clear cookies
    res.clearCookie("accessToken", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
    });
    res.clearCookie("refreshToken", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
    });

    return res.status(200).json({ message: "Logged out and cookies cleared!" });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Error clearing cookies. Check status of cookies" });
  }
});

module.exports = router; // Export the router object
