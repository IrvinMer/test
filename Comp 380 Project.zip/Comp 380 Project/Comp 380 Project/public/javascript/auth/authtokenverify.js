//***authtokenverify.js is client-side code that verifies the access token and refresh token
//***and logs the status of the access/refresh token
// Wait for the page to load
document.addEventListener("DOMContentLoaded", () => {
  // Get the login and profile buttons

  // Function to refresh the access token
  async function refreshAccessToken() {
    try {
      const refreshResponse = await fetch("auth/restart_token", {
        method: "POST",
        credentials: "include", // Include cookies
      });

      // Parse JSON data from response
      const data = await refreshResponse.json();

      // Log the message from the response
      console.log(data.message);

      if (refreshResponse.ok) {

        //if access token is refreshed, refresh the page
        const accessTokenRestartedMsg =
          "Access token refreshed! (It was expired!)";
        if (data.message === accessTokenRestartedMsg) {
          //redirect to home page with new access token to update the page
          window.location.href = "/";

        }

        // Fetch user data
        const userResponse = await fetch("auth/restart_token", {
          method: "GET",
          credentials: "include",
        });

        if (userResponse.ok) {
          //if response.status is 200
          const userData = await userResponse.json();

          // Log the user data
          console.log(userData);
        } else {
          //if response.status is not 200
          const errorData = await userResponse.json();
          console.log(errorData.message);
        }

        logTokenStatus(); // Log the token status after refreshing
      }
    } catch (error) {
      console.error("Error refreshing access token:", error);
    }
  }

  //log token status
  async function logTokenStatus() {
    try {
      const response = await fetch("auth/token_status", {
        method: "GET",
        credentials: "include",
      });

      if (response.ok) {
        const data = await response.json();
        console.log(data);
      } else {
        const errorData = await response.json();
        console.log(errorData.message);
      }
    } catch (error) {
      console.error("Error logging token status:", error);
    }
  }

  // Call this function every time the page is loaded or refreshed
  window.addEventListener("load", () => {
    refreshAccessToken(); // Refresh the access token on page load
  });
});
