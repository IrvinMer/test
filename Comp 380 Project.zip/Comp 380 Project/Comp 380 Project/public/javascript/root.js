//*** root.js is the client side code that is SPECIFICALLY for to the root endpoint (home screen).

document.addEventListener('DOMContentLoaded', () => {

});
